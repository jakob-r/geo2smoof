library(testthat)
library(geo2smoof)

test_check("geo2smoof")
